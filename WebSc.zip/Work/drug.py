#import module
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
import csv

path = "Documents/chromedriver.exe"
driver = webdriver.Chrome(path)

# url
driver.get('https://clinicaltrials.gov/ct2/show/NCT04322539')

# find web links
elems = driver.find_elements_by_css_selector(".doctor-upper [href]")
link = [elem.get_attribute('href') for elem in elems]

# print name of all links
#print (link)
f = open('drug.csv', 'w')
writer = csv.writer(f)



